
# Customer Churn Prediction & Retention Analysis

This project analyzes 50,000+ customer records to predict churn using Logistic Regression.
Tools used include Python, Pandas, and Scikit-learn.

## Key Highlights
- Data cleaning and EDA using Pandas
- Logistic Regression model with ~85% accuracy
- Identified key churn drivers
- Suggested retention strategies
